package com.example.simanste.javareviewapp;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;

public class MainActivity extends AppCompatActivity {

    public static final String EXTRA_TOPIC = "com.example.javareviewapp.TOPIC";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
    }

    public void openMemoryQuiz(View view) {
        Intent intent = new Intent(this, Quiz.class);
        intent.putExtra(EXTRA_TOPIC, "1");
        startActivity(intent);
    }

    public void openConceptsQuiz(View view) {
        Intent intent = new Intent(this, Quiz.class);
        intent.putExtra(EXTRA_TOPIC, "2");
        startActivity(intent);
    }

    public void openStructuresQuiz(View view) {
        Intent intent = new Intent(this, Quiz.class);
        intent.putExtra(EXTRA_TOPIC, "3");
        startActivity(intent);
    }

    public void openCodingQuiz(View view) {
        Intent intent = new Intent(this, Quiz.class);
        intent.putExtra(EXTRA_TOPIC, "4");
        startActivity(intent);
    }


}
