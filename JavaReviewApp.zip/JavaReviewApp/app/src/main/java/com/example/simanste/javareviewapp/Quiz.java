package com.example.simanste.javareviewapp;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.widget.RadioButton;
import android.widget.TextView;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.util.ArrayList;
import java.util.Collections;

public class Quiz extends AppCompatActivity {

    String question;
    TextView updateLabel;
    TextView questionLabel;
    RadioButton choiceA;
    RadioButton choiceB;
    RadioButton choiceC;
    RadioButton choiceD;
    ArrayList<String> fileContents = new ArrayList<String>();
    ArrayList<QA> QAList = new ArrayList<QA>();



    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_quiz);

        updateLabel = findViewById(R.id.updateLabel);
        questionLabel = findViewById(R.id.questionLabel);
        choiceA = findViewById(R.id.choiceA);
        choiceB = findViewById(R.id.choiceB);
        choiceC = findViewById(R.id.choiceC);
        choiceD = findViewById(R.id.choiceD);

        Intent intent = getIntent();
        String topic = intent.getStringExtra(MainActivity.EXTRA_TOPIC);

        if (topic.equals("1")) {
            readMemoryQs();
        }
//        else if (topic.equals("2")){
//            quiz.readConceptQs();
//        } else if (topic.equals("3")) {
//            quiz.readStructureQs();
//        } else {
//            quiz.readCodingQs();
//        }

        addQAs();
        displayQA();
    }

    public void addQAs(){

        for (int i=0; i<fileContents.size();i+=5){
            ArrayList<String> choices = new ArrayList<String>();
            choices.add(fileContents.get(i+1));
            choices.add(fileContents.get(i+2));
            choices.add(fileContents.get(i+3));
            choices.add(fileContents.get(i+4));
            QA cqa = new QA(fileContents.get(i), fileContents.get(i+1), choices);
            QAList.add(cqa);
        }

    }

    public void displayQA(){
        questionLabel.setText(QAList.get(0).getQuestion());
        Collections.shuffle(QAList.get(0).choices);
        choiceA.setText(QAList.get(0).choices.get(0));
        choiceB.setText(QAList.get(0).choices.get(1));
        choiceC.setText(QAList.get(0).choices.get(2));
        choiceD.setText(QAList.get(0).choices.get(3));
    }

    public void readMemoryQs(){
        try {
            InputStream stream = getAssets().open("memoryQuestions.txt");
            BufferedReader breader = new BufferedReader(new InputStreamReader(stream));
            String line = breader.readLine();
            while ( line != null){
                fileContents.add(line);
                line = breader.readLine();
            }
        } catch (IOException e) {
            updateLabel.setText(e.toString());
        }
    }
}
